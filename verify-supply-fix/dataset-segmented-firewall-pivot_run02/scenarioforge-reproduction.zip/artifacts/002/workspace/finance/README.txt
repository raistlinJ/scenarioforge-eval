Finance terminal home folder. Reconciliation files are local only.
