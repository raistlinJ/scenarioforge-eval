#!/bin/sh
set -eu
LOGIN_USER="${LOGIN_USER:-player}"
LOGIN_PASS="${LOGIN_PASS:-}"
AUTH_MODE="${AUTH_MODE:-password}"
TIMEOUT_SECONDS="${TIMEOUT_SECONDS:-0}"

if ! id "$LOGIN_USER" >/dev/null 2>&1; then
  useradd -m -s /bin/bash "$LOGIN_USER"
fi

if [ -n "$LOGIN_PASS" ]; then
  echo "$LOGIN_USER:$LOGIN_PASS" | chpasswd
fi

mkdir -p "/home/$LOGIN_USER/.ssh"
if [ -f /challenge/keys/id_ed25519.pub ]; then
  cp -f /challenge/keys/id_ed25519.pub "/home/$LOGIN_USER/.ssh/authorized_keys"
fi
if [ -d /challenge/workspace ]; then
  cp -a /challenge/workspace/. "/home/$LOGIN_USER/" 2>/dev/null || true
fi
chown -R "$LOGIN_USER:$LOGIN_USER" "/home/$LOGIN_USER"
chmod 700 "/home/$LOGIN_USER/.ssh" || true
chmod 600 "/home/$LOGIN_USER/.ssh/authorized_keys" 2>/dev/null || true

PASS_AUTH=no
PUB_AUTH=no
if [ "$AUTH_MODE" = "password" ] || [ "$AUTH_MODE" = "dual" ]; then
  PASS_AUTH=yes
fi
if [ "$AUTH_MODE" = "key" ] || [ "$AUTH_MODE" = "dual" ] || [ "$AUTH_MODE" = "sftp" ]; then
  PUB_AUTH=yes
fi

sed -ri "s/^#?PasswordAuthentication .*/PasswordAuthentication $PASS_AUTH/" /etc/ssh/sshd_config
sed -ri "s/^#?PubkeyAuthentication .*/PubkeyAuthentication $PUB_AUTH/" /etc/ssh/sshd_config
sed -ri 's/^#?PermitRootLogin .*/PermitRootLogin no/' /etc/ssh/sshd_config
grep -q '^UsePAM' /etc/ssh/sshd_config && sed -ri 's/^UsePAM .*/UsePAM no/' /etc/ssh/sshd_config || echo 'UsePAM no' >> /etc/ssh/sshd_config
grep -q '^AuthorizedKeysFile' /etc/ssh/sshd_config && sed -ri 's#^AuthorizedKeysFile .*#AuthorizedKeysFile .ssh/authorized_keys#' /etc/ssh/sshd_config || echo 'AuthorizedKeysFile .ssh/authorized_keys' >> /etc/ssh/sshd_config

case "$TIMEOUT_SECONDS" in
  ''|0) ;;
  *)
    printf 'TMOUT=%s
readonly TMOUT
export TMOUT
' "$TIMEOUT_SECONDS" > /etc/profile.d/coretg-timeout.sh
    echo "ClientAliveInterval $TIMEOUT_SECONDS" >> /etc/ssh/sshd_config
    echo 'ClientAliveCountMax 1' >> /etc/ssh/sshd_config
    ;;
esac

if [ "$AUTH_MODE" = "sftp" ]; then
  printf '
Match User %s
  ForceCommand internal-sftp
  X11Forwarding no
  AllowTcpForwarding no
' "$LOGIN_USER" >> /etc/ssh/sshd_config
fi

mkdir -p /var/run/sshd
SSHD_PID=""
term_handler() {
  if [ -n "$SSHD_PID" ] && kill -0 "$SSHD_PID" 2>/dev/null; then
    kill -TERM "$SSHD_PID" 2>/dev/null || true
    wait "$SSHD_PID" 2>/dev/null || true
  fi
  exit 143
}
trap term_handler TERM INT
/usr/sbin/sshd -D -e &
SSHD_PID="$!"
wait "$SSHD_PID"
