Deferred and bounced messages are exposed in this fixture.
