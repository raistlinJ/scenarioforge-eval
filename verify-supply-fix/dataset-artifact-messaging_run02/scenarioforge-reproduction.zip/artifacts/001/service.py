#!/usr/bin/env python3
import json
import os
import socketserver
from pathlib import Path


ROOT = Path(os.environ.get("SERVICE_ROOT", "/srv/service")).resolve()
CONFIG = json.loads((ROOT / "config.json").read_text("utf-8"))


def _safe_path(raw):
    rel = str(raw or "").strip().replace("\\", "/").lstrip("/")
    if not rel:
        return None
    candidate = (ROOT / rel).resolve()
    try:
        candidate.relative_to(ROOT)
    except Exception:
        return None
    if not candidate.exists() or not candidate.is_file():
        return None
    return candidate


def _read_rel(raw):
    path = _safe_path(raw)
    if path is None:
        return "ERR not found\n"
    return path.read_text("utf-8", errors="replace")


def _listing():
    rows = []
    for path in sorted(ROOT.rglob("*")):
        if path.name == "config.json" or not path.is_file():
            continue
        rows.append(str(path.relative_to(ROOT)).replace("\\", "/"))
    return "\n".join(rows) + ("\n" if rows else "")


class Handler(socketserver.StreamRequestHandler):
    def setup(self):
        super().setup()
        self.authed = CONFIG.get("auth") in ("none", "anonymous", "guest")

    def write(self, text):
        self.wfile.write(str(text).encode("utf-8", "replace"))

    def _check_auth(self):
        if self.authed:
            return True
        self.write("ERR authentication required\n")
        return False

    def _auth(self, parts):
        if CONFIG.get("auth") in ("none", "anonymous", "guest"):
            self.authed = True
            self.write("OK anonymous access\n")
            return
        if len(parts) >= 3 and parts[1] == CONFIG.get("username") and parts[2] == CONFIG.get("password"):
            self.authed = True
            self.write("OK authenticated\n")
            return
        self.write("ERR invalid credentials\n")

    def _http_get(self, line):
        try:
            path = line.split()[1].split("?", 1)[0].lstrip("/") or "README.txt"
        except Exception:
            path = "README.txt"
        body = _read_rel(path)
        status = "200 OK" if not body.startswith("ERR ") else "404 Not Found"
        response = f"HTTP/1.1 {status}\r\nContent-Type: text/plain\r\nContent-Length: {len(body.encode('utf-8'))}\r\n\r\n{body}"
        self.write(response)

    def _protocol_alias(self, raw, upper):
        protocol = CONFIG.get("protocol")
        parts = raw.split()
        if protocol == "ftp":
            if upper.startswith("USER "):
                self.write("331 password required\n")
                return True
            if upper.startswith("PASS "):
                if CONFIG.get("auth") == "password":
                    expected = CONFIG.get("password")
                    self.authed = raw.split(None, 1)[1].strip() == expected if len(parts) > 1 else False
                else:
                    self.authed = True
                self.write("230 login ok\n" if self.authed else "530 login incorrect\n")
                return True
            if upper == "LIST":
                if self._check_auth():
                    self.write(_listing())
                return True
            if upper.startswith("RETR "):
                if self._check_auth():
                    self.write(_read_rel(raw.split(None, 1)[1]))
                return True
        if protocol == "smb" and upper in ("SHARES", "DIR"):
            if self._check_auth():
                self.write(_listing())
            return True
        if protocol == "dns":
            if upper.startswith("AXFR") or upper.startswith("TXT"):
                self.write(_read_rel(CONFIG.get("flag_path")))
                return True
        if protocol == "redis":
            if upper.startswith("KEYS"):
                self.write(_listing())
                return True
            if upper.startswith("GET "):
                self.write(_read_rel(raw.split(None, 1)[1].replace(":", "_") + ".txt"))
                return True
        if protocol == "memcached":
            if upper == "STATS":
                self.write(_read_rel("cache/stats.txt"))
                return True
            if upper.startswith("GET "):
                self.write(_read_rel("cache/" + raw.split(None, 1)[1] + ".txt"))
                return True
        if protocol == "smtp":
            if upper.startswith("EHLO") or upper.startswith("HELO"):
                self.write("250-coretg relay\n250 HELP\n")
                return True
            if upper.startswith("VRFY") or upper == "QUEUE":
                self.write(_read_rel(CONFIG.get("flag_path")))
                return True
        if protocol == "imap":
            if upper.startswith("LOGIN"):
                if len(parts) >= 3 and parts[1] == CONFIG.get("username") and parts[2] == CONFIG.get("password"):
                    self.authed = True
                    self.write("OK LOGIN completed\n")
                else:
                    self.write("NO LOGIN failed\n")
                return True
            if upper.startswith("FETCH"):
                if self._check_auth():
                    self.write(_read_rel(CONFIG.get("flag_path")))
                return True
        if protocol == "ldap":
            if upper.startswith("BIND"):
                self._auth(["AUTH"] + parts[1:])
                return True
            if upper.startswith("SEARCH"):
                if self._check_auth():
                    self.write(_read_rel(CONFIG.get("flag_path")))
                return True
        if protocol == "mqtt":
            if upper.startswith("SUB"):
                if self._check_auth():
                    self.write(_read_rel(CONFIG.get("flag_path")))
                return True
        return False

    def handle(self):
        self.write(CONFIG.get("banner", "service ready") + "\n")
        self.write("Commands: HELP, INFO, AUTH <user> <password>, LIST, GET <path>\n")
        while True:
            line = self.rfile.readline(4096)
            if not line:
                return
            raw = line.decode("utf-8", "replace").strip()
            if not raw:
                continue
            upper = raw.upper()
            if raw.startswith("GET ") and " HTTP/" in raw:
                self._http_get(raw)
                return
            parts = raw.split()
            if upper in ("QUIT", "EXIT"):
                self.write("bye\n")
                return
            if upper == "HELP":
                self.write(CONFIG.get("help", "Use LIST and GET <path>.\n"))
                continue
            if upper == "INFO":
                self.write(json.dumps({k: CONFIG.get(k) for k in ("variant_id", "service", "protocol", "title", "endpoint")}, indent=2) + "\n")
                continue
            if upper.startswith("AUTH "):
                self._auth(parts)
                continue
            if self._protocol_alias(raw, upper):
                continue
            if upper == "LIST":
                if self._check_auth():
                    self.write(_listing())
                continue
            if upper.startswith("GET "):
                if self._check_auth():
                    self.write(_read_rel(raw.split(None, 1)[1]))
                continue
            self.write("ERR unknown command\n")


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True


if __name__ == "__main__":
    port = int(os.environ.get("SERVICE_PORT", str(CONFIG.get("port", 9000))))
    with Server(("0.0.0.0", port), Handler) as server:
        server.serve_forever()
