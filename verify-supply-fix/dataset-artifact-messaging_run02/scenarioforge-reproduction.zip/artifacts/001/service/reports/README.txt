Aggregate reports queued for analyst review.
